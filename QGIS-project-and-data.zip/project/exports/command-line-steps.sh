#########################################
# Set up variables and remove prior runs
#
# Input DEM
input='../DEM_40m.tif'

# Resample DEM
resolution='1000'

# Z factor to increase relief in hillshade
z='14'

# Digital number from hillshade
DN='5 30 100'

# Ouput directory for polygonized hillshade
output=relief$resolution$z

# Goodbye!
rm e*.tif
#
#########################################

echo "Let's go!"

#########################################

gdalwarp -tr $resolution $resolution -r near -of GTiff $input eDEM.tif

gdaldem hillshade eDEM.tif eHillshade-$z.tif -of GTiff -b 1 -z $z -s 1.0 -az 315.0 -alt 45.0

mkdir $output

for value in $DN; do
    gdal_calc.py -A eHillshade-$z.tif --outfile=eRelief-$value.tif --calc="A <= $value"
    gdal_polygonize.py eRelief-$value.tif relief-$value.gpkg -b 1 -f "GPKG" relief-$value DN
    ogr2ogr -f GPKG $output/relief-$value.gpkg -where "DN = 1" relief-$value.gpkg
    rm relief-$value.gpkg
done

